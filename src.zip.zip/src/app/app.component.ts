import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {

  nome :string='CristianAngular';
  imagem='https://i.imgur.com/zfUMWMj.png';
  minhafuncao():void{
    alert('clicou')
  }
condicao1=true;
condicao2=false;
nomeDigitado=''
listaDeMoradores= [
  { name:'Claudio', numero: 30 }
  { name:'Cristian', numero: 74 }
]
}